from . import ai

def vibeiseven(bool):
    return ai.vibeiseven(bool)